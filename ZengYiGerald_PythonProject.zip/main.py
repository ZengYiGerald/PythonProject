#########################################################################
#Title: PYTHON Project Scenario - Data Analysis
#Description: This program allows user to analyse.......
#Name: <ZengYiGerald>
#Group Name: <KGN>
#Class: <PN2004J>
#Date: <9/2/2021>
#Version: <1.0>
#########################################################################

#########################################################################
#IMPORT Pandas Library for Data Analysis
#########################################################################
#import pandas for data analysis
import pandas as pd
#########################################################################
#IMPORT Pandas Library for Data Analysis
#########################################################################

#########################################################################
#CLASS Branch - Data Analysis
#load excel data (CSV format) to dataframe
#########################################################################
class DataAnalysis:
  def __init__(self):

    #load excel data (CSV format) to dataframe - 'df'
    dataframe = pd.read_csv('MonthyVisitors.csv')
    #show specific country dataframe
    sortCountry(dataframe)
#########################################################################
#CLASS Branch: End of Code
#########################################################################

#########################################################################
#FUNCTION Branch - sortCountry
#parses data and displays sorted result(s)
#########################################################################
def sortCountry(df):

  #print number of rows in dataframe
  print("There are " + str(len(df)) + " data rows read. \n")

  #display dataframe (rows and columns)
  print("The following dataframe are read as follows: \n")
  print(df)

  #display a specific Region (Asia-Pacific)
  country_label = (df[['Year', 'Month', ' Japan ', ' Hong Kong ', ' China ', ' Taiwan ', ' Korea, Republic Of ']][216:348])

  print("\n" + "Asia-Pacific Region was selected.")
  print("\n", + country_label)

  #####################################################
  #calcalate the number of total vistors from 1996-2006
  #####################################################

  #####################################################################################################
  #total_japan  = df.iloc[216:348, 9].sum(axis=0)
  #print("The number of vistors from Japan in 1996 to 2006 is: ", ('{:,}'.format(total_japan)))

  #total_hongkong = df.iloc[216:348, 10].sum(axis=0)
  #print("The number of vistors from Hong Kong in 1996 to 2006 is: ", ('{:,}'.format(total_hongkong)))

  #total_china = df.iloc[216:348, 11].sum(axis=0)
  #print("The number of vistors from China in 1996 to 2006 is: ", ('{:,}'.format(total_china)))

  #total_taiwan = df.iloc[216:348, 12].sum(axis=0)
  #print("The number of vistors from Taiwan in 1996 to 2006 is: ", ('{:,}'.format(total_taiwan)))

  #total_korea = df.iloc[216:348, 13].sum(axis=0)
  #print("The number of vistors from Korea in 1996 to 2006 is: ", ('{:,}'.format(total_korea)))
  #####################################################################################################
  
  #making a dataframe for Asia-Pacific Region visitors from 1996-2006
  ap_region = {'Country': ['Japan', 'Hong Kong', 'China', 'Taiwan', 'Korea, Republic of'], 'Visitors': ['8595057', '3017823', '6073384', '3191138', '3550115']}

  #print(" The" + sea_region + "was sorted in ascending order. \n")
  df = pd.DataFrame(ap_region,columns=['Country', 'Visitors'])
  sorted_df = df.sort_values(by=['Visitors'], ascending=False)
  print("\n\n" + "Period: 1996 - 2006")
  print("Region: Asia-Pacific")
  print("\n" + "The total vistiors are listed in a table below:" + "\n\n", + sorted_df)

  #import matplotlib.pyplot as pit
  import matplotlib.pyplot as pit

  activities = ['Japan', 'Hong Kong', 'China', 'Taiwan', 'Korea, Republic of']
  visitors = [8595057, 3017823, 6073384, 3191138, 3550115]
  exp = [0.2, 0, 0, 0, 0]
  cl = ['red', 'green', 'yellow', 'blue', 'brown']

  pit.pie(visitors, labels=activities, explode=exp, shadow=True, colors=cl, autopct='%2.2f%%')

  pit.legend()
  pit.show()

  return
#########################################################################
#FUNCTION Branch: End of Code
#########################################################################

#########################################################################
#Main Branch
#########################################################################
if __name__ == '__main__':
  
  #Project Title
  print('######################################')
  print('# Data Analysis App - PYTHON Project #')
  print('######################################')

  #perform data analysis on specific excel (CSV) file
  DataAnalysis()

#########################################################################
#Main Branch: End of Code
######################################################################### 